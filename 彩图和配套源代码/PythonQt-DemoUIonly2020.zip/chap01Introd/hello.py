
str="Hello world"

print(str)
